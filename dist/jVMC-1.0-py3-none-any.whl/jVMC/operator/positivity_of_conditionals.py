import numpy as np
import sys
sys.path.append(sys.path[0] + "/../..")
import jVMC


povm = jVMC.operator.povm.POVM()


def idx_to_base(idx, N):
    res = np.zeros(N, dtype=np.int64)
    power = N
    while idx > 0:
        res[power - 1] = idx % 4**(N - power + 1)
        idx -= res[power - 1]
        power -= 1

    for i, r in enumerate(res):
        res[i] = r / 4**(N - 1 - i)

    return res


def get_M_NBody(N, povm):
    M_N_Body = []
    for idx in range(4**N):
        kron_prod = 1. + 0.j
        base_rep = idx_to_base(idx, N)
        for n in range(N):
            kron_prod = np.kron(kron_prod, povm.M[base_rep[n]])
        M_N_Body.append(kron_prod)
    return M_N_Body


def get_T_inv(M):
    T = np.einsum('aij, bji -> ab', M, M)
    return np.linalg.inv(T)


def comp_P_cond(P, n, base_rep):
    P_A_and_B = np.sum(P[tuple(base_rep[0:n + 1])], axis=tuple(range(1, len(base_rep) - n - 1)))
    P_B = np.sum(P[tuple(base_rep[0:n + 1])], axis=tuple(range(0, len(base_rep) - n - 1)))
    P_A_giv_B = P_A_and_B / P_B
    return P_A_giv_B


def get_random_rho(N):
    rho = np.random.random(size=(2**N, 2**N)) + 1.j * np.random.random(size=(2**N, 2**N))
    rho = rho.dot(np.conj(rho.T)) / np.trace(rho.dot(np.conj(rho.T)))
    return rho


N = 2
M_N_Body = get_M_NBody(N, povm)
rho = np.random.random(size=(2**N, 2**N)) + 1.j * np.random.random(size=(2**N, 2**N))
rho = rho.dot(np.conj(rho.T)) / np.trace(rho.dot(np.conj(rho.T)))
P = np.array([np.real(np.trace(rho.dot(M))) for M in M_N_Body]).reshape((4,) * N)


counter = 0
eigvals_list = []
for idx in range(4**N):
    # find basis representation: convert idx 19 of a 3 spin system into base_rep = [1, 0, 3]
    # with kernel K = [16, 4, 1] such that 19 = base_rep.dot(K)
    base_rep = idx_to_base(idx, N)
    for n in range(N):
        P_cond = comp_P_cond(P, n, base_rep)
        # print(P_cond)
        if type(P_cond) == type(np.array([])):
            counter += 1
            rho_cond = np.einsum('aij, ab, b', povm.M, povm.T_inv, P_cond)
            eigvals, eigvecs = np.linalg.eig(rho_cond)
            eigvals_list.append(eigvals)

            meas_op = 1
            for j in range(n):
                meas_op = np.kron(meas_op, povm.M[j])
            rho_uptoN = np.sum(rho.reshape((2, 2) * N), axis=tuple(range(2 * n, 2 * N - 1)))
            rho_cond_2 = np.sum(rho_uptoN.dot(meas_op), axis=tuple(range(0, 2 * n - 1)))
            print(np.linalg.norm(rho_cond_2 - rho_cond))

            print(eigvals)
        # print(P_cond)
print(counter)
print(np.min(np.real(eigvals_list)))
print(np.max(np.imag(eigvals_list)))


N = 2
M_N_Body = get_M_NBody(N, povm)
T_inv = get_T_inv(M_N_Body)


rho_A = get_random_rho(1)
P_a = np.array([np.trace(rho_A.dot(M)).real for M in povm.M])
rho_cond = [get_random_rho(1) for _ in range(4)]
P_b_giv_a = np.array([[np.trace(rho_cond[idx].dot(M)).real for M in povm.M] for idx in range(4)])
P_complete = P_a[:, None] * P_b_giv_a


# rho_complete = get_random_rho(N)
# P_complete = np.array([np.trace(M.dot(rho_complete)) for M in M_N_Body])

rho_reconstructed = np.einsum('aij, ab, b', M_N_Body, T_inv, P_complete.reshape(-1))
eigvals, _ = np.linalg.eig(rho_reconstructed)
print(eigvals.real)

rho_sum = np.sum(rho_cond[0:3], axis=0)
eigvals, _ = np.linalg.eig(rho_sum)
print(eigvals.real)


for M in povm.M:
    print(M)

print(povm.unitaries["X"])
